#ifndef STUDINFO_H_INCLUDED
#define STUDINFO_H_INCLUDED
#include "Student.h"

class Studinfo
{
private:
    Student stud;
public:


    Studinfo();
    ~Studinfo();
};

#endif // STUDINFO_H_INCLUDED
